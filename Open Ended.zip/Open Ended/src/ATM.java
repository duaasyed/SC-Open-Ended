import java.text.SimpleDateFormat;
import java.util.*;

public class ATM 
{
	private LinkedList<BankAccount> bankAccounts;
	private int withDrawFee;
	private double withDrawMoney, previousBalance, depositAmount,moneyToDeposit;
	Scanner SC = new Scanner(System.in);
	private String accountNumber;
	private String toAccountNumber;

	public ATM() 
	{
		super();
		this.bankAccounts = new LinkedList<BankAccount>();
		this.withDrawFee = 20;
		this.withDrawMoney = 0;
		this.accountNumber = "";
		this.toAccountNumber = "";
	}

	public ATM(LinkedList<BankAccount> bankAccounts) 
	{
		super();
		this.bankAccounts = bankAccounts;
		this.withDrawFee = 20;
		this.accountNumber = "";
		this.toAccountNumber = "";
	}

	public BankAccount getBankAccount(String accountNumber) 
	{
		return this.bankAccounts.get(this.getIndex(accountNumber));
	}

	public void setBankAccount(BankAccount bankAccount) 
	{
		this.bankAccounts.add(bankAccount);
	}

	private int getIndex(String accountNumber) 
	{
		int index = -1;
		for (int i = 0; i < this.bankAccounts.size(); i++)
		{
			if (this.bankAccounts.get(i).getAccountNumber().equals(accountNumber)) 
			{
				index = i;
			}
		}
		return index;

	}

	private boolean checkCredientialsValidity(String accountNumber, int pin)
	{
		this.accountNumber = accountNumber;
		boolean check = false;
		int index = this.getIndex(accountNumber);
		if (index != -1)
		{
			if (this.bankAccounts.get(index).getAccountNumber().toUpperCase().equals(accountNumber)
					&& this.bankAccounts.get(index).getCustomer().getPin() == pin) 
			{
				check = true;
			}
		} 
		else 
		{
			System.out.println("\t\t Account number: " + accountNumber + " is invalid\\t\\t");
			System.exit(0);
		}
		return check;
	}

	private double checkBalance()
	{
		return this.bankAccounts.get(this.getIndex(this.accountNumber)).getBalance();
	}

	private void desposit(double amount) 
	{
		this.depositAmount = amount;
		double temp = this.checkBalance();
		this.previousBalance = temp;
		this.bankAccounts.get(this.getIndex(this.accountNumber)).setBalance(amount + temp);
	}

	private void fundsTransfer(double amount, String toAccountNumber)
	{
		int toIndex = this.getIndex(toAccountNumber);
		this.withDraw(amount);
		if (toIndex != -1) 
		{
			if (this.bankAccounts.get(toIndex).getAccountNumber().equals(toAccountNumber)) 
			{
				this.moneyToDeposit=amount;
				double temp = this.bankAccounts.get(toIndex).getBalance();
				this.bankAccounts.get(this.getIndex(toAccountNumber)).setBalance(amount + temp);
			}
		} 
		else
		{
			System.out.println("\t\t Account number: " + toAccountNumber + " is invalid\\t\\t");
			this.desposit(amount);
			System.exit(0);
		}

	}

	private void withDraw(double amount) 
	{
		this.withDrawMoney = amount;
		double money = this.bankAccounts.get(this.getIndex(this.accountNumber)).getBalance();
		this.previousBalance = money;
		if (money > 0 && (money >= amount)) 
		{
			this.bankAccounts.get(this.getIndex(this.accountNumber))
					.setBalance((money - this.withDrawMoney) - this.withDrawFee);
		}

	}

	private void receipt(String transactionType) 
	{
		System.out.print("\n");
		System.out.println("------------------------------------------------------");
		System.out.println("\t | STATE BANK OF PAKISTAN |");
		System.out.println("------------------------------------------------------");
		System.out.println("\t | AUTO-GENERATED RECEIPT |");
		System.out.println("------------------------------------------------------");
		String transactionTime = new SimpleDateFormat(" HH:mm:ss | dd/MM/yy ").format(Calendar.getInstance().getTime());

		System.out.println(" TRANSACTION TIME & DATE:" + transactionTime);
		System.out.println(" ACCOUNT NUMBER: " + this.bankAccounts.get(this.getIndex(this.accountNumber)).getAccountNumber().toUpperCase());
		System.out.println(" ACCOUNT HOLDER: "+ this.bankAccounts.get(this.getIndex(this.accountNumber)).getCustomer().getName().toUpperCase());
	
		if (transactionType == "withdraw") 
		{
			System.out.print("\n Transaction = WITHDRAWAL CHECKING \n");
			System.out.print(" WITHDRAWAL FEE = Rs." + this.withDrawFee + ".00\n");
			System.out.println(" WITHDRAWAL AMOUNT = Rs." + this.withDrawMoney);
			System.out.println(" Previous BALANCE = Rs." + this.previousBalance);
			System.out.println(" CURRENT BALANCE = Rs." + this.checkBalance());
			System.out.println("------------------------------------------------------");
		}
		if (transactionType == "deposit")
		{
			System.out.print("\n Transaction = DEPOSIT CHECKING \n");
			System.out.println(" DEPOSIT AMOUNT = Rs." + this.depositAmount);
			System.out.println(" Previous BALANCE = Rs." + this.previousBalance);
			System.out.println(" CURRENT BALANCE = Rs." + this.checkBalance());
			System.out.println("------------------------------------------------------");
		}
		if (transactionType == "another") 
		{
			System.out.print("\n TRANSACTION = FUNDS TRANSFER \n");
			System.out.println(" SENDER ACCOUNT NUMBER =" + this.accountNumber);
			System.out.println(" RECEIVER ACCOUNT NUMBER =" + this.toAccountNumber);
			System.out.println(" DEPOSIT AMOUNT = Rs." + this.moneyToDeposit);
			System.out.println(" PREVIOUS BALANCE = Rs." + this.previousBalance);
			System.out.println(" CURRENT BALANCE = Rs." + this.checkBalance());
			System.out.println("------------------------------------------------------");
		}
		if (transactionType == "check")
		{
			System.out.print("\n TRANSACTION = CHECk BALANCE \n");
			System.out.println(" CURRENT BALANCE = Rs." + this.checkBalance());
			System.out.println("------------------------------------------------------");
		}

	}

	public void evoke()
	{
		System.out.println(" CUSTOMER CREDENTIALS");
		System.out.print("\t Account Number: ");
		String acountNumber = this.SC.next();
		System.out.print("\t Account PIN: ");
		int pin = this.SC.nextInt();
		if (this.checkCredientialsValidity(acountNumber, pin)) 
		{
			this.Menu();
		} 
		else 
		{
			System.out.println("Invalid Credientials");
		}
	}

	private void Menu() 
	{
		System.out.print("\n");
		System.out.println(" ------------------");
		System.out.println("     USER MENU");
		System.out.println(" ------------------");
		System.out.println(" (1) WithDraw Money ");
		System.out.println(" (2) Deposit Money  ");
		System.out.println(" (3) Check Balance ");
		System.out.println(" (4) FUNDS TRANSFER \n");
		
		System.out.print(" Enter Your Choice:");
		
		
		int choice = this.SC.nextInt();
		
		if (choice == 1) 
		{
			System.out.print(" Enter Withdrawal Amount: ");
			double amount = SC.nextDouble();
			this.withDraw(amount);
			this.receipt("withdraw");
		} 
		else if (choice == 2)
		{
			System.out.print(" Enter Deposit Amount: ");
			double amount = SC.nextDouble();
			this.desposit(amount);
			this.receipt("deposit");
		}
		else if (choice == 3)
		{
			this.receipt("check");
		}
		else if (choice == 4) 
		{
			System.out.print(" Enter Account Number: ");
			this.toAccountNumber = this.SC.next();
			System.out.print(" Enter Amount: ");
			double amount = SC.nextDouble();
			this.fundsTransfer(amount, this.toAccountNumber);
			this.receipt("another");
		} 
		else
		{
			System.out.println("\n Invalid choice!!");
		}

	}

}
