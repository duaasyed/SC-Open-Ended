import java.util.LinkedList;

public class Bank 
{
	private String bankName, branchName;
	private LinkedList<BankAccount> accounts;
	private ATM atm;

	public Bank() 
	{
		this.accounts = new LinkedList<BankAccount>();
		this.bankName = this.branchName = "";
	}

	public Bank(String bankName, String branchName, LinkedList<BankAccount> accounts, ATM atm)
	{
		this.accounts = accounts;
		this.atm = atm;
		this.branchName = branchName;
		this.bankName = bankName;
	}

	public String getName() 
	{
		return bankName;
	}

	public void setName(String bankName) 
	{
		this.bankName = bankName;
	}

	public String getBranch() 
	{
		return branchName;
	}

	public void setBranch(String branch)
	{
		this.branchName = branch;
	}

	public BankAccount getBankAccount(String accountNumber) 
	{
		for (int i = 0; i < this.accounts.size(); i++) 
		{
			if (this.accounts.get(i).getAccountNumber().toUpperCase().equals(accountNumber.toUpperCase())) {
				return this.accounts.get(i);
			}
		}
		
		return null;
	}

	public void setBankAccount(BankAccount bankAccount)
	{
		this.accounts.add(bankAccount);
		
	}

	public ATM getAtm() 
	{
		return atm;
	}

	public void setAtm(ATM atm)
{
		this.atm = atm;
	}

}
