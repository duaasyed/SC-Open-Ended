
public class BankAccount
{
	private String accountNumber;
	private Customer customer;
	private double balance, limit;

	public BankAccount()
	{
		super();
		this.accountNumber = "";
		this.customer = new Customer();
		this.balance = this.limit = 0f;
	}

	public BankAccount(String accountNumber, Customer customer, double balance, double limit) 
	{
		super();
		this.accountNumber = accountNumber;
		this.customer = customer;
		this.balance = balance;
		this.limit = limit;
	}

	public String getAccountNumber() 
	{
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber)
	{
		this.accountNumber = accountNumber;
		
	}

	public Customer getCustomer()
	{
		return customer;
	}

	public void setCustomer(Customer customer) 
	{
		this.customer = customer;
	}

	public double getBalance() 
	{
		return balance;
	}

	public void setBalance(double balance)
	{
		if (balance > 0 && balance <= this.limit)
		{
			this.balance = balance;
		}
	}

	public double getAmountLimit() 
	{
		return limit;
	}

	public void setAmountLimit(double limit)
	{
		if (limit > 0) 
		{
			this.limit = limit;
		}

	}

}
