
public class Customer 
{
	private String username, contact, idCard;
	private int cardPinNumber;

	public Customer() 
	{
		super();
		this.cardPinNumber = 0;
		this.contact = this.idCard = this.username = "";
		
	}

	public Customer(String name, String contactNumber, String id_card, int pin) 
	{
		super();
		this.username = name;
		this.contact = contactNumber;
		this.idCard = id_card;
		this.cardPinNumber = pin;
	}

	public int getPin() 
	{
		return cardPinNumber;
	}

	public void setPin(int cardPinNumber) 
	{
		this.cardPinNumber = cardPinNumber;
	}

	public String getName()
	{
		return username;
	}

	public void setName(String username)
	{
		this.username = username;
	}

	public String getContactNumber() 
	{
		return contact;
	}

	public void setContactNumber(String contactNumber)
	{
		this.contact = contactNumber;
	}

	public String getIdCard() 
	{
		return idCard;
	}

	public void setIdCard(String idCard)
	{
		this.idCard = idCard;
	}

}
