import java.util.LinkedList;

public class StateBank 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		System.out.println("\t\t SYEDA DUAA FATIMA BUKHARI \t\t");
		System.out.println(" \t\t      01-131182-035 \t\t\n");
		
		LinkedList<BankAccount> account1 = new LinkedList<BankAccount>();
		
		LinkedList<Customer> customers = new LinkedList<Customer>();

		customers.add(new Customer("Duaa Syed", "0331-9123459", "34301-5448992-2", 4562));
		customers.add(new Customer("Natasha Shahid", "0307-5674389", "34502-2265527-9", 3111));
		customers.add(new Customer("Hayyan Khan", "0336-6574890", "36602-2145506-9", 1234));
		customers.add(new Customer("Saad Iqbal", "0323-2923897", "36502-3639797-5", 8502));

		account1.add(new BankAccount("0001", customers.get(0), 80000, 400000));
		account1.add(new BankAccount("1542", customers.get(1), 65000, 300000));
		account1.add(new BankAccount("3625", customers.get(2), 97000, 500000));
		account1.add(new BankAccount("9111", customers.get(3), 84000, 400000));

		ATM one = new ATM(account1);


		LinkedList<Bank> bank = new LinkedList<Bank>();
		bank.add(new Bank("State Bank Of Pakistan", "Lahore Branch", account1, one));
		
		one.evoke();
	}

}
